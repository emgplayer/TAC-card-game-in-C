#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <time.h>
#include <windows.h>
unsigned long x;
unsigned long p = 11;
unsigned long q = 19;
unsigned long M = 209;

void SetSeed(unsigned long seed)
{
    x = seed % M;
    if (x == 0)
    {
        x = 3;
    }
}

unsigned long bbs_next(void)
{
    x = (x * x) % M;
    return x;
}

int parityBit(unsigned long num)
{
    int count = 0;

    while (num > 0)
    {
        if (num % 2 == 1)
        {
            count++;
        }
        num = num / 2;
    }

    if (count % 2 == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int RandomBit(void)
{
    unsigned long value = bbs_next();
    return parityBit(value);
}

unsigned int RandomNumber(int bits)
{
    unsigned int num = 0;

    for (int i = 0; i < bits; i++)
    {
        num = (num << 1) | RandomBit();
    }

    return num;
}

typedef struct node
{
    void* info;
    struct node* next;
}node;

typedef struct list
{
    node *first, *last;
    int num_elements;
}list;

void make_list(list* l)
{
    l->first = NULL;
    l->last = NULL;
    l->num_elements = 0;
}

node* getNode(void* element)
{
    node* newNode = (node*)malloc(sizeof(node));

    if (newNode == NULL)
    {
        printf("greska pri alokaciji memorije\n");
        exit(1);
    }

    newNode->info = element;
    newNode->next = NULL;

    return newNode;
}

void dodaj_na_pocetak(list *l, void* element)
{
    node* new_element = getNode(element);
    if(l->first == NULL)
    {
        l -> first = new_element;
        l->last = new_element;
    }
    else
    {
        new_element -> next = l -> first;
        l->first = new_element;
    }
    l->num_elements++;
}

void dodaj_na_kraj(list* l, void* element)
{
    node* new_element = getNode(element);
    if(l->first == NULL)
    {
        l -> first = new_element;
        l->last = new_element;
    }
    else
    {
        l->last->next = new_element;
        l->last = new_element;
    }
    l->num_elements++;
}

void* ukloni_sa_pocetka(list* l)
{
    if (l->first == NULL)
    {
        return NULL;
    }

    node* remove = l->first;
    void* data = remove->info;

    l->first = l->first->next;

    if (l->first == NULL)
    {
        l->last = NULL;
    }

    free(remove);
    l->num_elements--;

    return data;
}

void* ukloni_sa_kraja(list* l)
{
    if (l->first == NULL)
    {
        return NULL;
    }

    node* remove = l->last;
    void* data = remove->info;

    if (l->first == l->last)
    {
        l->first = NULL;
        l->last = NULL;
    }
    else
    {
        node* temp = l->first;
        while (temp->next != l->last)
        {
            temp = temp->next;
        }

        temp->next = NULL;
        l->last = temp;
    }

    free(remove);
    l->num_elements--;

    return data;
}

void* pogledaj_pocetak(list* l)
{
    if (l->first == NULL)
    {
        return NULL;
    }
    return l->first->info;
}

void* pogledaj_kraj(list* l)
{
    if (l->last == NULL)
    {
        return NULL;
    }
    return l->last->info;
}

bool je_prazna(list* l)
{
    return ((l->first == NULL)? true : false);
}

int velicina(list *l)
{
    return l->num_elements;
}

void push(list* s, void* element)
{
    dodaj_na_pocetak(s, element);
}

void* pop(list* s)
{
    return ukloni_sa_pocetka(s);
}

void* pogledaj_vrh_steka(list* s)
{
        return pogledaj_pocetak(s);
}

bool je_prazan(list* s)
{
    return je_prazna(s);
}

typedef struct {
    int rank;   //2 - 14
    char suit;  //h s d c
} Card;

Card p1[26];
Card p2[26];

void make_deck(Card deck[52])
{
    char suits[4] = {'h', 's', 'd', 'c'};
    int pos = 0;
    for(int i = 0; i < 4; i++)
    {
        for(int card_number = 1; card_number <   14; card_number++)
        {
            deck[pos].rank = card_number;
            deck[pos].suit = suits[i];
            pos++;
        }
    }
}

void swap_cards(Card* a, Card* b)
{
    Card temp = *a;
    *a = *b;
    *b = temp;
}

void shuffle_split(Card deck[52])
{
    for (int i = 51; i > 0; i--)
    {
        int j = RandomNumber(6) % (i + 1);
        swap_cards(&deck[i], &deck[j]);
    }
    for(int i = 0; i < 26; i++)
    {
        p1[i] = deck[i];
        p2[i] = deck[i + 26];
    }
}

void array_to_list_closed(Card arr[], int n, list* l)
{
    for (int i = 0; i < n; i++)
    {
        Card* newCard = (Card*)malloc(sizeof(Card));
        if (newCard == NULL)
        {
            printf("greska pri alokaciji memorije\n");
            break;
        }

        *newCard = arr[i];
        dodaj_na_kraj(l, newCard);
    }
}

void array_to_list_open(Card arr[], int n, list* l)
{

    for(int i = 0; i < n; i++)
    {
        Card* newCard = (Card*)malloc(sizeof(Card));
        if (newCard == NULL)
        {
            printf("greska pri alokaciji memorije\n");
            break;
        }

        *newCard = arr[i];
        push(l, newCard);
    }
}

void* draw_closed(list* l)
{
    if(je_prazna(l))
    {
        printf("nema karata u spilu");
        return NULL;
    }
    else
    {
        return ukloni_sa_pocetka(l);
    }
}

void* draw_open(list* l)
{
    if(je_prazan(l))
    {
        printf("Nemas karata ispred sebe");
        return NULL;
    }
    else
    {
        return pop(l);
    }
}

void place_on_middle(list* middle, Card* c)
{
    push(middle, c);
}
void place_on_own_open(list* my_open, Card* c)
{
    push(my_open, c);
}

void place_on_enemy_open(list* enemy_open, Card* c)
{
    push(enemy_open, c);
}

void print_card(Card* c)
{
    if(c == NULL)
    {
        printf("XXX");
    }
    else
    {
        printf("%d%c", c->rank, c->suit);
    }
}

//=========================================================================================================================================================

#define SIRINA   9
#define VISINA   7
#define BUF     64
#define KOLS     7

#define CH_H    '-'
#define CH_V    '|'
#define CH_TL   '+'
#define CH_TR   '+'
#define CH_BL   '+'
#define CH_BR   '+'
#define CH_DH   '-'   /* isprekidana horizontala (zatvoreni spil) */
#define CH_DV   ':'   /* isprekidana vertikala   (prazna karta)   */

/* -----------------------------------------------------------------------
 * Tip koji cuva jedan red karte
 * -------------------------------------------------------------------- */
typedef struct { char s[BUF]; } Red;
typedef struct { Red redovi[VISINA]; } Karta;

/* -----------------------------------------------------------------------
 * Pomocne funkcije
 * -------------------------------------------------------------------- */

static void razmaci(int n) {
    for (int i = 0; i < n; i++) putchar(' ');
}

static void centrirano(const char *tekst, int sir) {
    int d   = (int)strlen(tekst);
    int lev = (sir - d) / 2;
    int des = sir - d - lev;
    razmaci(lev);
    printf("%s", tekst);
    razmaci(des);
}

static void naziv(int v, char *buf) {
    switch (v) {
        case  1: strcpy(buf, " A"); break;
        case 11: strcpy(buf, " J"); break;
        case 12: strcpy(buf, " Q"); break;
        case 13: strcpy(buf, " K"); break;
        default: sprintf(buf, "%2d", v); break;
    }
}

/* -----------------------------------------------------------------------
 * Gradnja pojedinacnih redova
 * -------------------------------------------------------------------- */

static Red napravi_gornju(char tl, char h, char tr) {
    Red r;
    int pos = 0;
    r.s[pos++] = tl;
    for (int i = 0; i < SIRINA; i++) r.s[pos++] = h;
    r.s[pos++] = tr;
    r.s[pos]   = '\0';
    return r;
}

static Red napravi_srednji(char lv, const char *tekst, char align, char rv) {
    /* align: 'L' = levo, 'C' = centar, 'R' = desno */
    Red r;
    int d   = (int)strlen(tekst);
    int lev = 0, des = 0;
    if      (align == 'L') { lev = 0;              des = SIRINA - d; }
    else if (align == 'R') { lev = SIRINA - d;     des = 0;          }
    else                   { lev = (SIRINA-d)/2;   des = SIRINA-d-lev; }

    int pos = 0;
    r.s[pos++] = lv;
    for (int i = 0; i < lev; i++) r.s[pos++] = ' ';
    for (int i = 0; tekst[i]; i++) r.s[pos++] = tekst[i];
    for (int i = 0; i < des; i++) r.s[pos++] = ' ';
    r.s[pos++] = rv;
    r.s[pos]   = '\0';
    return r;
}

static Red napravi_prazan(char lv, char fill, char rv) {
    Red r;
    int pos = 0;
    r.s[pos++] = lv;
    for (int i = 0; i < SIRINA; i++) r.s[pos++] = fill;
    r.s[pos++] = rv;
    r.s[pos]   = '\0';
    return r;
}

/* -----------------------------------------------------------------------
 * Gradnja karata
 * -------------------------------------------------------------------- */

static Karta nacrtaj_kartu(int vrednost, const char *tekst_prazno) {
    Karta k;

    if (vrednost < 0) {
        char rec1[32] = "", rec2[32] = "";
        char kopija[64];
        strncpy(kopija, tekst_prazno, sizeof(kopija) - 1);
        kopija[sizeof(kopija)-1] = '\0';
        char *sp = strchr(kopija, ' ');
        if (sp) { *sp = '\0'; strcpy(rec1, kopija); strcpy(rec2, sp+1); }
        else    { strcpy(rec1, kopija); }

        k.redovi[0] = napravi_gornju(CH_TL, CH_H,  CH_TR);
        k.redovi[1] = napravi_prazan(CH_DV, ' ',   CH_DV);
        k.redovi[2] = napravi_srednji(CH_DV, rec1, 'C', CH_DV);
        k.redovi[3] = (rec2[0] != '\0')
                      ? napravi_srednji(CH_DV, rec2, 'C', CH_DV)
                      : napravi_prazan(CH_DV, ' ', CH_DV);
        k.redovi[4] = napravi_prazan(CH_DV, ' ',   CH_DV);
        k.redovi[5] = napravi_prazan(CH_DV, ' ',   CH_DV);
        k.redovi[6] = napravi_gornju(CH_BL, CH_H,  CH_BR);
        return k;
    }

    char nat[4];
    naziv(vrednost, nat);

    k.redovi[0] = napravi_gornju  (CH_TL, CH_H, CH_TR);
    k.redovi[1] = napravi_srednji (CH_V, nat, 'L', CH_V);
    k.redovi[2] = napravi_prazan  (CH_V, ' ', CH_V);
    k.redovi[3] = napravi_srednji (CH_V, nat, 'C', CH_V);
    k.redovi[4] = napravi_prazan  (CH_V, ' ', CH_V);
    k.redovi[5] = napravi_srednji (CH_V, nat, 'R', CH_V);
    k.redovi[6] = napravi_gornju  (CH_BL, CH_H, CH_BR);
    return k;
}

static Karta nacrtaj_zatvoreni(int broj) {
    Karta k;
    char tekst[16];
    if (broj == 0) strcpy(tekst, "prazan");
    else           snprintf(tekst, sizeof(tekst), "[%d]", broj);

    k.redovi[0] = napravi_gornju  (CH_TL, CH_H,  CH_TR);
    k.redovi[1] = napravi_prazan  (CH_V,  CH_DH, CH_V);
    k.redovi[2] = napravi_prazan  (CH_V,  CH_DH, CH_V);
    k.redovi[3] = napravi_srednji (CH_V,  tekst, 'C', CH_V);
    k.redovi[4] = napravi_prazan  (CH_V,  CH_DH, CH_V);
    k.redovi[5] = napravi_prazan  (CH_V,  CH_DH, CH_V);
    k.redovi[6] = napravi_gornju  (CH_BL, CH_H,  CH_BR);
    return k;
}

/* -----------------------------------------------------------------------
 * Glavni prikaz
 * -------------------------------------------------------------------- */

void prikazi_stanje(
    int broj_karata_zatvorenog_1,
    int vrh_otvorenog_1,
    int trenutno_izvucena_1,
    int broj_karata_zatvorenog_2,
    int vrh_otvorenog_2,
    int trenutno_izvucena_2,
    int vrh_sredisnje
) {
    Karta k[KOLS];
    k[0] = nacrtaj_zatvoreni(broj_karata_zatvorenog_1);
    k[1] = nacrtaj_kartu(trenutno_izvucena_1, "nije izvucena");
    k[2] = nacrtaj_kartu(vrh_otvorenog_1,     "prazan");
    k[3] = nacrtaj_kartu(vrh_sredisnje,        "prazan");
    k[4] = nacrtaj_kartu(vrh_otvorenog_2,     "prazan");
    k[5] = nacrtaj_kartu(trenutno_izvucena_2, "nije izvucena");
    k[6] = nacrtaj_zatvoreni(broj_karata_zatvorenog_2);

    /* Razmaci izmedju kolona */
    int r[6] = {2, 2, 8, 8, 2, 2};

    /* Naslov */
    printf("\n");
    printf("+");
    for (int i = 0; i < 76; i++) printf("-");
    printf("+\n");
    printf("|          TRENUTNO STANJE STOLA"
           "                                    |\n");
    printf("+");
    for (int i = 0; i < 76; i++) printf("-");
    printf("+\n\n");

    /* Natpisi kolona */
    const char *naslovi[KOLS] = {
        "Zatvoreni I1", "Izvucena I1", "Otvoreni I1",
        "Sredisnja",
        "Otvoreni I2",  "Izvucena I2", "Zatvoreni I2"
    };
    razmaci(2);
    for (int c = 0; c < KOLS; c++) {
        centrirano(naslovi[c], SIRINA + 2);
        if (c < KOLS - 1) razmaci(r[c]);
    }
    printf("\n");

    /* Redovi karata */
    for (int i = 0; i < VISINA; i++) {
        razmaci(2);
        for (int c = 0; c < KOLS; c++) {
            printf("%s", k[c].redovi[i].s);
            if (c < KOLS - 1) razmaci(r[c]);
        }
        printf("\n");
    }
    printf("\n");
}

//================================================================================================================================================

void now_state(
    list* player1_closed, list* player1_open,
    Card* drawn1,
    list* middle,
    list* player2_open, list* player2_closed,
    Card* drawn2) {
    int broj_karata_zatvorenog_1 = velicina(player1_closed);
    int broj_karata_zatvorenog_2 = velicina(player2_closed);

    Card* vrh_otvorenog_1 = pogledaj_vrh_steka(player1_open);
    Card* vrh_otvorenog_2 = pogledaj_vrh_steka(player2_open);

    Card* vrh_sredisnje = pogledaj_vrh_steka(middle);

    int rank_vrh_otvorenog_1 = vrh_otvorenog_1 ? vrh_otvorenog_1->rank : -1;
    int rank_vrh_otvorenog_2 = vrh_otvorenog_2 ? vrh_otvorenog_2->rank : -1;
    int rank_vrh_sredisnje  = vrh_sredisnje  ? vrh_sredisnje->rank  : -1;
    int rank_drawn1          = drawn1          ? drawn1->rank          : -1;
    int rank_drawn2          = drawn2          ? drawn2->rank          : -1;

    prikazi_stanje(broj_karata_zatvorenog_1, rank_vrh_otvorenog_1, rank_drawn1, broj_karata_zatvorenog_2,
                   rank_vrh_otvorenog_2, rank_drawn2, rank_vrh_sredisnje);
}

void refill_closed_open(list* closed, list* open)
{
    while(!je_prazan(open))
    {
        void* card = pop(open);
        dodaj_na_kraj(closed, card);
    }
}

int main()
{
    Card deck[52];
    list p1_cl, p1_op, p2_cl, p2_op, mid;

    make_list(&p1_cl);
    make_list(&p1_op);
    make_list(&p2_cl);
    make_list(&p2_op);
    make_list(&mid);

    Card* drawn1 = NULL;
    Card* drawn2 = NULL;

    int initialized = 0;   // da li je spil promesan i podeljen
    int izbor;

    while (1)
    {
        system("cls");
        printf("===== KARTASKA IGRA =====\n");
        printf("1. Promesaj spil i podeli karte\n");
        printf("2. Potez igraca 1\n");
        printf("3. Potez igraca 2\n");
        printf("4. Prikazi trenutno stanje\n");
        printf("0. Izlaz\n");
        printf("Izbor: ");

        if (scanf("%d", &izbor) != 1)
        {
            printf("\nNepostojeca opcija (morate uneti broj).\n");
            while (getchar() != '\n');
            Sleep(2000);
            continue;
        }

        if (izbor == 0)
        {
            printf("Izlaz iz programa.\n");
            break;
        }

        switch (izbor)
        {
            case 1:
            {
                // reset svih listi
                make_list(&p1_cl);
                make_list(&p1_op);
                make_list(&p2_cl);
                make_list(&p2_op);
                make_list(&mid);

                drawn1 = NULL;
                drawn2 = NULL;
                int seed;
                printf("Unesite seed za mesanje spila:\n");
                if (scanf("%d", &seed) != 1)
                {
                    printf("\nNepostojeca opcija (morate uneti broj).\n");
                    while (getchar() != '\n');
                    Sleep(2000);
                    continue;
                }
                SetSeed(seed);
                make_deck(deck);
                shuffle_split(deck);

                array_to_list_closed(p1, 26, &p1_cl);
                array_to_list_closed(p2, 26, &p2_cl);

                initialized = 1;

                printf("\nSpil je promesan i karte su podeljene.\n");
                getchar();
                getchar();
                break;
            }

            case 2:
            {
                if (!initialized)
                {
                    printf("\nPrvo promesaj spil i podeli karte!\n");
                    getchar();
                    getchar();
                    break;
                }

                int podizbor1;

pocetak1:
    while (1)
    {
        system("cls || clear");

        if (velicina(&p1_cl) == 0 && velicina(&p1_op) == 0 && drawn1 == NULL)
        {
            printf("Igrac 1 je pobedio!!!\n");
            Sleep(2000);
            goto end;
        }

        if (velicina(&p1_cl) == 0 && velicina(&p1_op) > 0)
        {
            refill_closed_open(&p1_cl, &p1_op);
        }

        printf("===== POTEZ IGRACA 1 =====\n");
        printf("1. Vuci kartu sa zatvorenog spila\n");
        printf("2. Vuci kartu sa otvorenog spila\n");
        printf("3. Postavi izvucenu kartu na sredinu\n");
        printf("4. Postavi izvucenu kartu kod protivnika\n");
        printf("5. Postavi kartu na svoju gomilu i zavrsi potez\n");
        printf("6. Prikazi trenutno stanje\n");
        printf("Izbor: ");

        scanf("%d", &podizbor1);

        switch (podizbor1)
        {
            case 1:
                if (drawn1 != NULL)
                {
                    printf("\nIgrac 1 vec ima izvucenu kartu! Prvo je postavi.\n");
                    Sleep(2000);
                    goto pocetak1;
                }
                else
                {
                    drawn1 = (Card*)draw_closed(&p1_cl);
                    if (drawn1 != NULL)
                    {
                        printf("\nIgrac 1 je izvukao: ");
                        print_card(drawn1);
                        printf("\n");
                    }
                }
                getchar();
                getchar();
                goto pocetak1;

            case 2:
                if (drawn1 != NULL)
                {
                    printf("\nIgrac 1 vec ima izvucenu kartu! Prvo je postavi.\n");
                    Sleep(2000);
                    goto pocetak1;
                }
                else
                {
                    drawn1 = (Card*)draw_open(&p1_op);
                    if (drawn1 != NULL)
                    {
                        printf("\nIgrac 1 je izvukao sa otvorenog: ");
                        print_card(drawn1);
                        printf("\n");
                    }
                }
                getchar();
                getchar();
                goto pocetak1;

            case 3:
                if (drawn1 == NULL)
                {
                    printf("\nIgrac 1 nema izvucenu kartu.\n");
                    Sleep(2000);
                    goto pocetak1;
                }
                else
                {
                    Card* vrh = (Card*)pogledaj_vrh_steka(&mid);

                    if (vrh == NULL)
                    {
                        if (drawn1->rank == 1)
                        {
                            place_on_middle(&mid, drawn1);
                            printf("\nIgrac 1 je stavio kartu na sredinu.\n");
                            drawn1 = NULL;
                        }
                        else
                        {
                            printf("Ne mozes da odigras ovaj potez");
                        }
                    }
                    else if ((drawn1->rank == 1 && vrh->rank == 13) || drawn1->rank == vrh->rank + 1)
                    {
                        place_on_middle(&mid, drawn1);
                        printf("\nIgrac 1 je stavio kartu na sredinu.\n");
                        drawn1 = NULL;
                    }
                    else
                    {
                        printf("Ne mozes da odigras ovaj potez");
                    }
                }
                getchar();
                getchar();
                goto pocetak1;

            case 4:
                if (drawn1 == NULL)
                {
                    printf("\nIgrac 1 nema izvucenu kartu.\n");
                    Sleep(2000);
                    goto pocetak1;
                }
                else
                {
                    Card* vrh = (Card*)pogledaj_vrh_steka(&p2_op);

                    if (vrh == NULL)
                    {
                        printf("Protivnicka otvorena gomila je prazna.\n");
                    }
                    else if ((drawn1->rank == 1 && vrh->rank == 13) || drawn1->rank == vrh->rank + 1)
                    {
                        place_on_enemy_open(&p2_op, drawn1);
                        printf("\nIgrac 1 je stavio kartu kod protivnika.\n");
                        drawn1 = NULL;
                    }
                    else
                    {
                        printf("Ne mozes da odigras ovaj potez");
                    }
                }
                getchar();
                getchar();
                goto pocetak1;

            case 5:
                if (drawn1 == NULL)
                {
                    printf("\nIgrac 1 nema izvucenu kartu.\n");
                    Sleep(2000);
                    goto pocetak1;
                }
                else
                {
                    place_on_own_open(&p1_op, drawn1);
                    printf("\nIgrac 1 je stavio kartu na svoju gomilu i zavrsio potez.\n");
                    drawn1 = NULL;
                }
                getchar();
                getchar();
                break;

            case 6:
                now_state(&p1_cl, &p1_op, drawn1, &mid, &p2_op, &p2_cl, drawn2);
                getchar();
                getchar();
                goto pocetak1;

            default:
                printf("\nNepostojeca opcija.\n");
                getchar();
                getchar();
                Sleep(2000);
                goto pocetak1;
        }

        break;
    }
    break;
}
                    case 3:
            {
                if (!initialized)
                {
                    printf("\nPrvo promesaj spil i podeli karte!\n");
                    getchar();
                    getchar();
                    break;
                }

                int podizbor2;

pocetak2:
                while (1)
                {
                    system("cls");

                    if (velicina(&p2_cl) == 0 && velicina(&p2_op) == 0 && drawn2 == NULL)
                    {
                        printf("Igrac 2 je pobedio!!!\n");
                        Sleep(2000);
                        goto end;
                    }

                    if (velicina(&p2_cl) == 0 && velicina(&p2_op) > 0)
                    {
                        refill_closed_open(&p2_cl, &p2_op);
                    }

                    printf("===== POTEZ IGRACA 2 =====\n");
                    printf("1. Vuci kartu sa zatvorenog spila\n");
                    printf("2. Vuci kartu sa otvorenog spila\n");
                    printf("3. Postavi izvucenu kartu na sredinu\n");
                    printf("4. Postavi izvucenu kartu kod protivnika\n");
                    printf("5. Postavi kartu na svoju gomilu i zavrsi potez\n");
                    printf("6. Prikazi trenutno stanje\n");
                    printf("Izbor: ");

                    scanf("%d", &podizbor2);

                    switch (podizbor2)
                    {
                        case 1:
                            if (drawn2 != NULL)
                            {
                                printf("\nIgrac 2 vec ima izvucenu kartu! Prvo je postavi.\n");
                                Sleep(2000);
                                goto pocetak2;
                            }
                            else
                            {
                                drawn2 = (Card*)draw_closed(&p2_cl);
                                if (drawn2 != NULL)
                                {
                                    printf("\nIgrac 2 je izvukao: ");
                                    print_card(drawn2);
                                    printf("\n");
                                }
                            }
                            getchar();
                            getchar();
                            goto pocetak2;

                        case 2:
                            if (drawn2 != NULL)
                            {
                                printf("\nIgrac 2 vec ima izvucenu kartu! Prvo je postavi.\n");
                                Sleep(2000);
                                goto pocetak2;
                            }
                            else
                            {
                                drawn2 = (Card*)draw_open(&p2_op);
                                if (drawn2 != NULL)
                                {
                                    printf("\nIgrac 2 je izvukao sa otvorenog: ");
                                    print_card(drawn2);
                                    printf("\n");
                                }
                            }
                            getchar();
                            getchar();
                            goto pocetak2;

                        case 3:
                            if (drawn2 == NULL)
                            {
                                printf("\nIgrac 2 nema izvucenu kartu.\n");
                                Sleep(2000);
                                goto pocetak2;
                            }
                            else
                            {
                                Card* vrh = (Card*)pogledaj_vrh_steka(&mid);

                                if (vrh == NULL)
                                {
                                    if (drawn2->rank == 1)
                                    {
                                        place_on_middle(&mid, drawn2);
                                        printf("\nIgrac 2 je stavio kartu na sredinu.\n");
                                        drawn2 = NULL;
                                    }
                                    else
                                    {
                                        printf("Ne mozes da odigras ovaj potez");
                                    }
                                }
                                else if ((drawn2->rank == 1 && vrh->rank == 13) || drawn2->rank == vrh->rank + 1)
                                {
                                    place_on_middle(&mid, drawn2);
                                    printf("\nIgrac 2 je stavio kartu na sredinu.\n");
                                    drawn2 = NULL;
                                }
                                else
                                {
                                    printf("Ne mozes da odigras ovaj potez");
                                }
                            }
                            getchar();
                            getchar();
                            goto pocetak2;

                        case 4:
                            if (drawn2 == NULL)
                            {
                                printf("\nIgrac 2 nema izvucenu kartu.\n");
                                Sleep(2000);
                                goto pocetak2;
                            }
                            else
                            {
                                Card* vrh2 = (Card*)pogledaj_vrh_steka(&p1_op);

                                if (vrh2 == NULL)
                                {
                                    printf("Protivnicka otvorena gomila je prazna.\n");
                                }
                                else if ((drawn2->rank == 1 && vrh2->rank == 13) || drawn2->rank == vrh2->rank + 1)
                                {
                                    place_on_enemy_open(&p1_op, drawn2);
                                    printf("\nIgrac 2 je stavio kartu kod protivnika.\n");
                                    drawn2 = NULL;
                                }
                                else
                                {
                                    printf("Ne mozes da odigras ovaj potez");
                                }
                            }
                            getchar();
                            getchar();
                            goto pocetak2;

                        case 5:
                            if (drawn2 == NULL)
                            {
                                printf("\nIgrac 2 nema izvucenu kartu.\n");
                                Sleep(2000);
                                goto pocetak2;
                            }
                            else
                            {
                                place_on_own_open(&p2_op, drawn2);
                                printf("\nIgrac 2 je stavio kartu na svoju gomilu i zavrsio potez.\n");
                                drawn2 = NULL;
                            }
                            getchar();
                            getchar();
                            break;

                        case 6:
                            now_state(&p1_cl, &p1_op, drawn1, &mid, &p2_op, &p2_cl, drawn2);
                            getchar();
                            getchar();
                            goto pocetak2;

                        default:
                            printf("\nNepostojeca opcija.\n");
                            getchar();
                            getchar();
                            Sleep(2000);
                            goto pocetak2;
                    }

                    break;
                }
                break;
            }

            case 4:
            {
                if (!initialized)
                {
                    printf("\nPrvo promesaj spil i podeli karte!\n");
                }
                else
                {
                    now_state(&p1_cl, &p1_op, drawn1, &mid, &p2_op, &p2_cl, drawn2);
                }
                getchar();
                getchar();
                break;
            }

            case 0:
                return 0;

            default:
            {
                printf("\nNepostojeca opcija.\n");
                getchar();
                getchar();
                break;
            }
        }
    }
end: printf("Kraj igre!!!");
    return 0;
}
